# Bộ nộp Assignment8 — Quách Hồng Nhân, 23130216

1. Mở Report/index.html để xem23 kết quả cá nhân và ảnh trích từ suite chung. Các file source-group-* giữ dữ liệu nhóm gốc để truy ngược, không dùng tổng nhóm làm số cá nhân.
2. Source/ chứa script cá nhân và cấu hình/fixture chung đúng phiên bản thực thi. Từ Source/: npm ci; npm run test:hongnhan. npm test trong bản ZIP chỉ tìm thấy các file HN đã đóng gói.
3. TEST-DESIGN.md là thiết kế bổ sung, RUN-REPORT.md là phân tích, STABILITY-CHECK.md ghi kết quả chạy lại.
4. Evidence/ giữ log lệnh, source hash và ảnh lỗi cá nhân trước sửa. Ảnh của lượt cuối nằm trong Report/images/.

Đếm23 test runner, không đếm số mãPC ghép trong tiêu đề thành từng kết quả độc lập. Những case chưa triển khai có ghi rõ, không giả Pass. Thời gian cá nhân là tổng duration của23 test trong cùng lượt nhóm, không cộng các lần chạy; wall time nhóm ghi riêng.
