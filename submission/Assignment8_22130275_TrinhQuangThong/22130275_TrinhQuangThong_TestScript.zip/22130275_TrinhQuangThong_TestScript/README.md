# ASM8 cá nhân — Trịnh Quang Thông, 22130275, Group15

## Mở từ đâu?

1. Mở **Report/index.html** sau giải nén để xem kết quả và bấm liên kết ảnh từng case.
2. Đọc **RUN-REPORT.md** để biết phạm vi, lỗi đã điều tra và phần chưa thực thi.
3. **Source/** chứa 11 file source thực tế đã chạy. **Evidence/** chứa ảnh và log.

Kết quả ngày 05/11/2026: **64 Passed, 0 Failed, 18 Skipped** trong 82 khai báo. Đây là ba chức năng cá nhân, chưa phải suite tất cả thành viên. PPTX nộp riêng ngoài ZIP.

## Cài và chạy

Cần Node.js >=20 và Google Chrome. Dùng Chrome đã cài, không sao chép profile/cookie.

```bash
cd Source
npm ci
npm test
# Hoặc chạy riêng:
npm run test:pd
npm run test:cp
npm run test:rv
```

Lượt chạy mới tạo `Test Report - Group 15/` và `Envidence - Group15/` cạnh Source/. Hai thư mục Report/ và Evidence/ đi kèm là minh chứng lịch sử đã chọn lọc.

Runner chạy headed, một worker, retries=0. Gặp 403/CAPTCHA thì dừng phần bị chặn. Giỏ/mua/payload giữ skip, kể cả ALLOW_CART=1. Mười lăm case RV form/validation chỉ có khai báo skip. Không đăng nhập hoặc gửi review.

Mô tả package.json còn nhãn PD lịch sử, nhưng config và testDir thực tế chứa cả CP/RV/PD. Gói giữ nguyên byte source để đối chiếu lượt chạy.

## Cấu trúc gọn

- Source/: hai spec và các file cấu hình, fixture, reporter, runner.
- Report/: HTML tổng hợp dễ mở, JSON từng case và tóm tắt lần chạy lại CP/RV.
- Evidence/Cases/: một file cho mỗi nội dung ảnh khác nhau. Nhiều case có thể cùng tham chiếu một ảnh khi SHA-256 trùng.
- Evidence/Logs/: console, command, exit code và hash source gốc.
- Evidence/PlaywrightReport/: ảnh báo cáo HTML gốc, Test Steps và log lưu.
- MANIFEST-SHA256.txt: hash kiểm tra toàn vẹn của các file trong gói.

Không có node_modules, trace viewer, trace.zip, bản sao workbook hoặc bài thành viên khác. HTML Playwright gốc đầy đủ vẫn nằm trong repository tại `assignment8/Test Report - Group 15/asm8-20261105222818-34028/index.html` cùng data/. HTML trong ZIP là bản tổng hợp từ kết quả thật, không phải bản xuất giao diện gốc.
