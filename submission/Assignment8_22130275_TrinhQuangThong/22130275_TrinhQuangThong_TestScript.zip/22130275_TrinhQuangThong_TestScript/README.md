# ASM8 cá nhân — Trịnh Quang Thông, 22130275

Chỉ Trang chi tiết sản phẩm. Chưa phải bộ test toàn nhóm.

## Xem theo thứ tự

1. Mở RUN-REPORT.md: kết quả và điều tra hai test.
2. Mở Report/index.html: bảng kết quả, liên kết ảnh và lỗi thật.
3. Source/: code để cài và chạy. Evidence/: ảnh và log theo case/lượt.

## Cài và chạy

Node.js >=20 và Google Chrome.

```bash
cd Source
npm ci
npm run test:pd
```

Không cần cài hay mở các file JS/CJS riêng lẻ. Không bật ALLOW_CART. Lượt chạy mới tạo hai thư mục `Test Report - Group 15/` và `Envidence - Group15/` cạnh Source; Report/Evidence đi kèm là minh chứng nộp đã chọn lọc.

## Bản đóng gói gọn

Không có node_modules, trace viewer, trace.zip hoặc ảnh attachment trùng. Ảnh giữ nguyên byte từ lần chạy; có thể một ảnh được nhiều dòng report cùng tham chiếu nếu nội dung trùng. MANIFEST-SHA256.txt dùng để kiểm tra toàn vẹn, không phải bài cần mở để chấm. PPTX nộp riêng ngoài ZIP theo đề.
