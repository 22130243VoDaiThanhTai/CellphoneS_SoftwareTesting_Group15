# ASM8 — Trang chi tiết sản phẩm

Trịnh Quang Thông — 22130275 — Group15. Project chỉ có PD, chưa phải suite toàn nhóm.

## Cài và chạy

Node.js >=20 và Google Chrome.

```bash
npm ci
npm run test:list
npm run test:pd
```

`npm test` cũng chỉ chạy PD. Có 28 khai báo test, một worker, retries=0. Thêm giỏ, mua và payload giữ Skipped. Hai case giỏ vẫn khóa kể cả ALLOW_CART=1 do cleanup chưa xác minh. Không bật ALLOW_CART, không đăng nhập/checkout/gửi form.

Mặc định timeout 30s, expect 8s. Riêng COLOR_Select_02 và INFO_View_04 có timeout 60s: chờ dữ liệu khu vực tối đa 30s, kiểm tra phần tử mục tiêu tối đa 15s. Không retry để che lỗi.

## Cấu trúc code

- `tests/quangthong/22130275_TrinhQuangThong_ASM8.spec.js`: 28 case PD.
- `support/fixtures.cjs`: ghi nhận chặn 403, ảnh sau test.
- `support/summary-reporter.cjs`: kết quả thực tế từ runner.
- `scripts/run-suite.cjs`: lệnh chạy, log và exit code.
- `sources.json`: nguồn và hash script.

Mỗi lần chạy tạo run ID riêng, HTML/JSON/Markdown trong `../Test Report - Group 15/<run-id>/`, ảnh/log/trace trong `../Envidence - Group15/<run-id>/`.

Trong ZIP cá nhân, thư mục này tên Source/. Bản minh chứng gọn đi kèm nằm tại ../Report/index.html và ../Evidence/; đọc ../RUN-REPORT.md. Các thư mục kết quả Group15 chỉ được tạo mới khi bạn chạy script, khác bản minh chứng đã chọn lọc để nộp.
