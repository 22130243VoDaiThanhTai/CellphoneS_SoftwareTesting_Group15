# ASM8 — Ba chức năng cá nhân

Trịnh Quang Thông, 22130275, Group15. Chạy thật ngày 05/11/2026, đóng gói ngày 06/11/2026. Không chạy lại website khi làm slide và ZIP.

Run `asm8-20261105222818-34028`, source commit `3aac5f88f39f91bee67f95e80915ede868e1f12e`. **82 khai báo: 64 Passed, 0 Failed, 18 Skipped**. Thời gian 552,82854 giây, exit code 0, retries=0.

| Module | Passed | Failed | Skipped | Tổng |
|---|---:|---:|---:|---:|
| PD | 25 | 0 | 3 | 28 |
| CP | 25 | 0 | 0 | 25 |
| RV | 14 | 0 | 15 | 29 |
| Tổng | 64 | 0 | 18 | 82 |

64/82 khai báo đã thực thi (78,05%). Cả 64 test thực thi đạt Passed. Phạm vi này chưa phải suite cả nhóm.

## Phạm vi và giới hạn

- PD: 25 test thực thi, ba skip gồm thêm giỏ, mua và payload. Khóa an toàn vẫn giữ kể cả ALLOW_CART=1.
- CP: 25 implementation đã chạy. So sánh dùng danh sách riêng, có cleanup khay qua UI. Case nút Mua ngay chỉ đọc href, không bấm.
- RV: 14 implementation công khai. Mười lăm case form/input/attachment chỉ khai báo skip, gồm 12 case cần phiên tài khoản phù hợp và ba validation thiếu đặc tả/môi trường gửi thử.
- Người dùng xác nhận ngày 05/11 giữ ba validation RV Untested trong workbook: 14 ký tự, 1000 ký tự, 15 dấu cách. Không thay trạng thái workbook bằng kết quả skip của automation.
- Giá gốc PD là assertion có điều kiện. Khi không hiện giá gốc, phép so sánh giá gốc chưa thực thi.
- Nhánh rỗng RV phụ thuộc dữ liệu review thực tế. Code kiểm tra tiền đề số review bằng 0 cho nhánh 1–4 sao.
- Responsive PD/CP kiểm tra phần tử và geometry trong phạm vi code, chưa chứng minh khả năng đọc trên mọi thiết bị.

## Lỗi đã điều tra

1. PD trước đây lỗi tải ảnh/khuyến mãi khi khu vực còn “Đang tải...”. Đã chờ dữ liệu vùng cho riêng hai case, giữ assertion ảnh/khuyến mãi. Cả hai tiếp tục Passed trong run 82.
2. Baseline CP/RV `asm8-20261105215357-21251`: 30 Passed, 9 Failed, 15 Skipped. Các lỗi gồm modal/cookie chặn click, scope review sai, whitespace số sao và thông báo rỗng là một đoạn p chứa br.
3. Đã sửa locator theo DOM. Handler đóng/mở modal qua UI, bấm Từ chối cookie và khôi phục query. Đã bỏ click cookie thủ công bị đua với handler. Không force click, không xóa overlay bằng JavaScript, không catch để ép Pass.
4. Lượt CP/RV `asm8-20261105221047-29496`: 39 Passed, 0 Failed, 15 Skipped, 341,11 giây. Spec CP/RV, fixture và config có hash giống run 82. CP/RV trong run 82 lặp lại 39 Passed, 0 Failed, 15 Skipped. Không cộng hai lượt. Hai lượt chưa đảm bảo hết flaky lâu dài.

## Nguồn và cách đọc

Report/results.json giữ title, status, duration và annotation từ summary gốc. Chỉ chuyển đường dẫn ảnh thành tương đối, bổ sung ghi chú skip PD và SHA-256 của summary gốc để truy nguyên. Mười một file Source/ khớp logs/source-hashes.json của lượt chạy.

Evidence/Logs/ giữ nguyên console.log, command.json, exit.json và source-hashes.json. Report/repeat-check.json tóm tắt lượt 54 cùng hash source đối chiếu. Bản HTML Playwright đầy đủ và lịch sử điều tra vẫn giữ trong repository.

Evidence/Cases/ chọn một ảnh gốc cho mỗi case Passed. Ảnh trước cleanup hoặc ở tab mới được ưu tiên khi phù hợp. Các ảnh giống byte dùng chung một file. Mười tám case skip không có ảnh. Evidence/PlaywrightReport/ chứa ảnh báo cáo, steps và log gốc chụp ngày 06/11. Không sửa bộ đếm kết quả.

## Từng case

| Case | Kết quả | Minh chứng / lý do |
|---|---|---|
| PRODUCT_COMPARE_PAGE_Open_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_PAGE_Open_01_passed.png) |
| PRODUCT_COMPARE_LIST_Add_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_LIST_Add_01_passed.png) |
| PRODUCT_COMPARE_SEARCH_Open_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_SEARCH_Open_01_passed.png) |
| PRODUCT_COMPARE_SEARCH_Search_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_SEARCH_Search_01_passed.png) |
| PRODUCT_COMPARE_LIST_Add_02 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_LIST_Add_02_passed.png) |
| PRODUCT_COMPARE_LIST_Add_03 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_LIST_Add_03_passed.png) |
| PRODUCT_COMPARE_LIST_Add_04 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_LIST_Add_04_passed.png) |
| PRODUCT_COMPARE_LIST_Limit_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_LIST_Limit_01_passed.png) |
| PRODUCT_COMPARE_LIST_Duplicate_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_LIST_Add_01_passed.png) |
| PRODUCT_COMPARE_LIST_Remove_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_PAGE_Open_01_passed.png) |
| PRODUCT_COMPARE_LIST_Remove_02 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_LIST_Remove_02_passed.png) |
| PRODUCT_COMPARE_LIST_Replace_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_LIST_Add_02_passed.png) |
| PRODUCT_COMPARE_SPECS_View_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_PAGE_Open_01_passed.png) |
| PRODUCT_COMPARE_SPECS_View_02 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_PAGE_Open_01_passed.png) |
| PRODUCT_COMPARE_SPECS_View_03 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_LIST_Add_02_passed.png) |
| PRODUCT_COMPARE_SPECS_Open_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_SPECS_Open_01_passed.png) |
| PRODUCT_COMPARE_SEARCH_Search_02 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_SEARCH_Search_02_passed.png) |
| PRODUCT_COMPARE_SEARCH_Clear_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_SEARCH_Clear_01_passed.png) |
| PRODUCT_COMPARE_SEARCH_Input_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_SEARCH_Input_01_passed.png) |
| PRODUCT_COMPARE_SEARCH_Input_02 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_SEARCH_Input_02_passed.png) |
| PRODUCT_COMPARE_SEARCH_Input_03 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_SEARCH_Input_03_passed.png) |
| PRODUCT_COMPARE_PAGE_Reload_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_PAGE_Open_01_passed.png) |
| PRODUCT_COMPARE_PAGE_Open_02 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_PAGE_Open_02_passed.png) |
| PRODUCT_COMPARE_PAGE_View_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_PAGE_View_01_passed.png) |
| PRODUCT_COMPARE_PAGE_Responsive_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_COMPARE_PAGE_Responsive_01_passed.png) |
| PRODUCT_REVIEW_SUMMARY_View_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_REVIEW_SUMMARY_View_01_passed.png) |
| PRODUCT_REVIEW_SUMMARY_View_02 | passed | [Ảnh](Evidence/Cases/PRODUCT_REVIEW_SUMMARY_View_01_passed.png) |
| PRODUCT_REVIEW_SUMMARY_View_03 | passed | [Ảnh](Evidence/Cases/PRODUCT_REVIEW_SUMMARY_View_01_passed.png) |
| PRODUCT_REVIEW_SUMMARY_View_04 | passed | [Ảnh](Evidence/Cases/PRODUCT_REVIEW_SUMMARY_View_04_passed.png) |
| PRODUCT_REVIEW_SUMMARY_View_05 | passed | [Ảnh](Evidence/Cases/PRODUCT_REVIEW_SUMMARY_View_01_passed.png) |
| PRODUCT_REVIEW_FILTER_Select_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_REVIEW_FILTER_Select_01_passed.png) |
| PRODUCT_REVIEW_FILTER_Select_02 | passed | [Ảnh](Evidence/Cases/PRODUCT_REVIEW_FILTER_Select_02_passed.png) |
| PRODUCT_REVIEW_FILTER_Select_03 | passed | [Ảnh](Evidence/Cases/PRODUCT_REVIEW_FILTER_Select_03_passed.png) |
| PRODUCT_REVIEW_FILTER_Select_04 | passed | [Ảnh](Evidence/Cases/PRODUCT_REVIEW_FILTER_Select_04_passed.png) |
| PRODUCT_REVIEW_FILTER_Select_05 | passed | [Ảnh](Evidence/Cases/PRODUCT_REVIEW_FILTER_Select_05_passed.png) |
| PRODUCT_REVIEW_FILTER_Clear_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_REVIEW_FILTER_Clear_01_passed.png) |
| PRODUCT_REVIEW_FILTER_Select_06 | passed | [Ảnh](Evidence/Cases/PRODUCT_REVIEW_FILTER_Select_06_passed.png) |
| PRODUCT_REVIEW_FILTER_Select_07 | passed | [Ảnh](Evidence/Cases/PRODUCT_REVIEW_FILTER_Select_07_passed.png) |
| PRODUCT_REVIEW_LIST_Open_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_REVIEW_LIST_Open_01_passed.png) |
| PRODUCT_REVIEW_FORM_Open_01 | skipped | Cần phiên CellphoneS đăng nhập có sẵn. Project chạy context sạch, không sao chép cookie hoặc đăng nhập; không gửi đánh giá. |
| PRODUCT_REVIEW_FORM_View_01 | skipped | Cần phiên CellphoneS đăng nhập có sẵn. Project chạy context sạch, không sao chép cookie hoặc đăng nhập; không gửi đánh giá. |
| PRODUCT_REVIEW_RATING_Select_01 | skipped | Cần phiên CellphoneS đăng nhập có sẵn. Project chạy context sạch, không sao chép cookie hoặc đăng nhập; không gửi đánh giá. |
| PRODUCT_REVIEW_RATING_Switch_01 | skipped | Cần phiên CellphoneS đăng nhập có sẵn. Project chạy context sạch, không sao chép cookie hoặc đăng nhập; không gửi đánh giá. |
| PRODUCT_REVIEW_CONTENT_View_01 | skipped | Cần phiên CellphoneS đăng nhập có sẵn. Project chạy context sạch, không sao chép cookie hoặc đăng nhập; không gửi đánh giá. |
| PRODUCT_REVIEW_CONTENT_Clear_01 | skipped | Cần phiên CellphoneS đăng nhập có sẵn. Project chạy context sạch, không sao chép cookie hoặc đăng nhập; không gửi đánh giá. |
| PRODUCT_REVIEW_CONTENT_Validate_01 | skipped | Expected còn CẦN XÁC MINH trong workbook; cần đặc tả/môi trường cho phép gửi thử. Không suy từ nhập liệu sang validation. |
| PRODUCT_REVIEW_CONTENT_Input_01 | skipped | Cần phiên CellphoneS đăng nhập có sẵn. Project chạy context sạch, không sao chép cookie hoặc đăng nhập; không gửi đánh giá. |
| PRODUCT_REVIEW_CONTENT_Input_02 | skipped | Cần phiên CellphoneS đăng nhập có sẵn. Project chạy context sạch, không sao chép cookie hoặc đăng nhập; không gửi đánh giá. |
| PRODUCT_REVIEW_CONTENT_Limit_01 | skipped | Expected còn CẦN XÁC MINH trong workbook; cần đặc tả/môi trường cho phép gửi thử. Không suy từ nhập liệu sang validation. |
| PRODUCT_REVIEW_CONTENT_Validate_02 | skipped | Expected còn CẦN XÁC MINH trong workbook; cần đặc tả/môi trường cho phép gửi thử. Không suy từ nhập liệu sang validation. |
| PRODUCT_REVIEW_CONTENT_Input_03 | skipped | Cần phiên CellphoneS đăng nhập có sẵn. Project chạy context sạch, không sao chép cookie hoặc đăng nhập; không gửi đánh giá. |
| PRODUCT_REVIEW_CONTENT_Input_04 | skipped | Cần phiên CellphoneS đăng nhập có sẵn. Project chạy context sạch, không sao chép cookie hoặc đăng nhập; không gửi đánh giá. |
| PRODUCT_REVIEW_CONTENT_Security_01 | skipped | Cần phiên CellphoneS đăng nhập có sẵn. Project chạy context sạch, không sao chép cookie hoặc đăng nhập; không gửi đánh giá. |
| PRODUCT_REVIEW_ATTACHMENT_View_01 | skipped | Cần phiên CellphoneS đăng nhập có sẵn. Project chạy context sạch, không sao chép cookie hoặc đăng nhập; không gửi đánh giá. |
| PRODUCT_DETAIL_INFO_Open_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_INFO_Open_01_passed.png) |
| PRODUCT_DETAIL_INFO_View_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_INFO_Open_01_passed.png) |
| PRODUCT_DETAIL_INFO_View_02 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_INFO_Open_01_passed.png) |
| PRODUCT_DETAIL_INFO_View_03 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_INFO_View_03_passed.png) |
| PRODUCT_DETAIL_VARIANT_Select_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_VARIANT_Select_01_passed.png) |
| PRODUCT_DETAIL_VARIANT_Select_02 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_VARIANT_Select_02_passed.png) |
| PRODUCT_DETAIL_VARIANT_Switch_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_VARIANT_Switch_01_passed.png) |
| PRODUCT_DETAIL_VARIANT_Open_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_VARIANT_Open_01_passed.png) |
| PRODUCT_DETAIL_COLOR_Select_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_COLOR_Select_01_passed.png) |
| PRODUCT_DETAIL_COLOR_Select_02 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_COLOR_Select_02_passed.png) |
| PRODUCT_DETAIL_VARIANT_Switch_02 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_VARIANT_Switch_02_passed.png) |
| PRODUCT_DETAIL_GALLERY_Select_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_GALLERY_Select_01_passed.png) |
| PRODUCT_DETAIL_GALLERY_Navigate_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_GALLERY_Navigate_01_passed.png) |
| PRODUCT_DETAIL_GALLERY_Navigate_02 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_GALLERY_Navigate_02_passed.png) |
| PRODUCT_DETAIL_GALLERY_Open_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_GALLERY_Open_01_passed.png) |
| PRODUCT_DETAIL_INFO_View_04 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_INFO_Open_01_passed.png) |
| PRODUCT_DETAIL_INFO_Open_02 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_INFO_Open_02_passed.png) |
| PRODUCT_DETAIL_SPECS_View_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_INFO_Open_01_passed.png) |
| PRODUCT_DETAIL_SPECS_Open_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_SPECS_Open_01_passed.png) |
| PRODUCT_DETAIL_SPECS_Switch_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_SPECS_Switch_01_passed.png) |
| PRODUCT_DETAIL_ACTION_Add_01 | skipped | Giỏ/mua giữ khóa an toàn, cleanup chưa xác minh. |
| PRODUCT_DETAIL_ACTION_Buy_01 | skipped | Giỏ/mua giữ khóa an toàn, cleanup chưa xác minh. |
| PRODUCT_DETAIL_COLOR_Switch_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_COLOR_Select_01_passed.png) |
| PRODUCT_DETAIL_ERROR_Open_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_ERROR_Open_01_passed.png) |
| PRODUCT_DETAIL_ERROR_Security_01 | skipped | Không mở URL payload, tránh HTTP 403. |
| PRODUCT_DETAIL_COMPAT_Reload_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_COMPAT_Reload_01_passed.png) |
| PRODUCT_DETAIL_COMPAT_Navigate_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_VARIANT_Select_02_passed.png) |
| PRODUCT_DETAIL_COMPAT_View_01 | passed | [Ảnh](Evidence/Cases/PRODUCT_DETAIL_COMPAT_View_01_passed.png) |
